<!doctype html>
<html lang="en-US">

<head>
	<h1>This is my APP 3</h1>
<style>
    body { background-color: #0000FF; }
</style>
<title>BLUE - APP 3</title>
<?php echo '<p>Hello World</p>'; ?> 
</head>


</html>
