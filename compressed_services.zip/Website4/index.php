<!doctype html>
<html lang="en-US">

<head>
	<h1>This is my APP 4</h1>
<style>
    body { background-color: #800080; }
</style>
<title>PURPLE - APP 4</title>
<?php echo '<p>Hello World</p>'; ?> 
</head>


</html>
