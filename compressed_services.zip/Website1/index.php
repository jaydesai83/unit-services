<!doctype html>
<html lang="en-US">

<head>
	<h1>This is my APP 1</h1>
<style>
    body { background-color: #FF0000; }
</style>
<title>RED - APP 1</title>
<?php echo '<p>Hello World</p>'; ?>
</head>


</html>
