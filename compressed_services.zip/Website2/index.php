<!doctype html>
<html lang="en-US">

<head>
	<h1>This is my APP 2</h1>
<style>
    body { background-color: #00FF00; }
</style>
<title>GREEN - APP 2</title>
<?php echo '<p>Hello World</p>'; ?> 
</head>


</html>
